﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace MYAPP.CityInfo.Dtos
{
    public class CreateOrEditCityDto : EntityDto<int?>
    {

        public string Name { get; set; }

    }
}