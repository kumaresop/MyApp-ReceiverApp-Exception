﻿using System.Data.Entity;
using Abp.EntityFramework;
using MYAPP.CityInfo;
using MYAPP.PersonDetails;
using Microsoft.EntityFrameworkCore;

namespace AbpEfConsoleApp
{
    //EF DbContext class.
    public class MyConsoleAppDbContext : AbpDbContext
    {
        public virtual IDbSet<City> Cities { get; set; }

        public MyConsoleAppDbContext()
            : base("Default")
        {

        }

        public MyConsoleAppDbContext(string nameOrConnectionString)
            : base(nameOrConnectionString)
        {

        }
    }
}