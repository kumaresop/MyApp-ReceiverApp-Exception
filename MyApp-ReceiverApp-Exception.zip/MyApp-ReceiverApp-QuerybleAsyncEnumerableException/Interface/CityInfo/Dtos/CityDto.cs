﻿using System;
using Abp.Application.Services.Dto;

namespace MYAPP.CityInfo.Dtos
{
    public class CityDto : EntityDto
    {
        public string Name { get; set; }

    }
}