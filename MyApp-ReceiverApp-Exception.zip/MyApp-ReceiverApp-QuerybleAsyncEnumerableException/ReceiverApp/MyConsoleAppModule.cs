using System;
using System.IO;
using System.Reflection;
using Abp.Dependency;
using Abp.Domain.Repositories;
using Abp.EntityFramework;
using Abp.EntityFrameworkCore.Configuration;
using Abp.Modules;
using MYAPP.CityInfo;
using MYAPP.CityInfo.Exporting;
using MYAPP.Storage;
using Microsoft.Extensions.Configuration;

namespace AbpEfConsoleApp
{
    [DependsOn(typeof(AbpEntityFrameworkModule))]
    public class MyConsoleAppModule : AbpModule
    {
        public static string dbChoice = Console.ReadLine();
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(Assembly.GetExecutingAssembly());
            IocManager.Register<ICitiesAppService, CitiesAppService>(DependencyLifeStyle.Transient);
            IocManager.Register<ITempFileCacheManager, TempFileCacheManager>(DependencyLifeStyle.Transient);
            IocManager.Register<IRepository<City, int>>(DependencyLifeStyle.Transient);
            IocManager.Register<ICitiesExcelExporter, CitiesExcelExporter>(DependencyLifeStyle.Transient);
        }

        public override void PreInitialize()
        {

            var builder = new ConfigurationBuilder()
               .SetBasePath(Directory.GetCurrentDirectory())
               .AddJsonFile("appsettings.json", false)
               .AddEnvironmentVariables();

            IConfigurationRoot configuration = builder.Build();
            string dbconstr = configuration.GetConnectionString("Default");
            Console.WriteLine(dbconstr);

            Configuration.DefaultNameOrConnectionString = dbconstr;
        }       
    }
}