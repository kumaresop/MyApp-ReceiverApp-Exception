﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Abp;
using Abp.Castle.Logging.Log4Net;
using Abp.Dependency;
using AbpEfConsoleApp;
using Castle.Facilities.Logging;
using Microsoft.Extensions.Configuration;
using System.Linq;
using MYAPP.CityInfo.Dtos;
using MYAPP.CityInfo;
/*
 * The source IQueryable doesn't implement IAsyncEnumerable<MYAPP.PersonDetails.Dtos.AddressCountryLookupTableDto>. Only sources that implement IAsyncEnumerable can be used for Entity Framework asynchronous operations
 * */
namespace ReceiverApp
{
    class Program
    {
        static async Task Main(string[] args)
        //static void Main(string[] args)
        {
            //Bootstrapping ABP system
            using (var bootstrapper = AbpBootstrapper.Create<MyConsoleAppModule>())
            {
                bootstrapper.IocManager
                    .IocContainer
                    .AddFacility<LoggingFacility>(f => f.UseAbpLog4Net().WithConfig("log4net.config"));

                bootstrapper.Initialize();
                    await Test_AsyncServiceMethod(bootstrapper.IocManager);
            }

            Console.WriteLine("Hello World!");

        }

        //public static async Task<GetCityForEditOutput> Test_AsyncServiceMethod(IIocManager iocManager)
        public static async Task<List<CityDto>> Test_AsyncServiceMethod(IIocManager iocManager)
        {
            var cityAppService = iocManager.Resolve<CitiesAppService>();

            /*CityDto cityDto = new CityDto();
            cityDto.Id = 1;
            var result = await cityAppService.GetCityForEdit(cityDto);
            return result;
            */

            return await cityAppService.GetAllCities();
 
        }
    }
}
