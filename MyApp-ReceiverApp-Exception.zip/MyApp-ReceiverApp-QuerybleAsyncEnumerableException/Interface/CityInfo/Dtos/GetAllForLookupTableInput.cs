﻿using Abp.Application.Services.Dto;

namespace MYAPP.CityInfo.Dtos
{
    public class GetAllForLookupTableInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }
    }
}