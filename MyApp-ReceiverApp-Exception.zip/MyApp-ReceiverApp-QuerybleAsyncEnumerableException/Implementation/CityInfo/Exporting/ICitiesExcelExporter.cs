﻿using System.Collections.Generic;
using MYAPP.CityInfo.Dtos;
using MYAPP.Dto;

namespace MYAPP.CityInfo.Exporting
{
    public interface ICitiesExcelExporter
    {
        FileDto ExportToFile(List<GetCityForViewDto> cities);
    }
}