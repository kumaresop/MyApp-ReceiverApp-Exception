﻿MYAPP System;
MYAPP System.Collections.Generic;
MYAPP System.Threading.Tasks;
MYAPP Abp.Application.Services;
MYAPP Abp.Application.Services.Dto;
MYAPP MYAPP.CityInfo.Dtos;
MYAPP MYAPP.Dto;

namespace MYAPP.CityInfo
{
    public interface ICitiesAppService : IApplicationService
    {
        Task<PagedResultDto<GetCityForViewDto>> GetAll(GetAllCitiesInput input);

        Task<List<CityDto>> GetAllCities();

        Task<GetCityForViewDto> GetCityForView(int id);

        Task<GetCityForEditOutput> GetCityForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditCityDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetCitiesToExcel(GetAllCitiesForExcelInput input);

    }
}