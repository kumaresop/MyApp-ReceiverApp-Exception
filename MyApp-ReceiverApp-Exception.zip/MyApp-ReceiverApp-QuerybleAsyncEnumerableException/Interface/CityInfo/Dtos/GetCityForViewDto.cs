﻿namespace MYAPP.CityInfo.Dtos
{
    public class GetCityForViewDto
    {
        public CityDto City { get; set; }

    }
}